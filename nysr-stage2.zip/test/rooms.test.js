'use strict';
// Интеграционный тест комнат: node test/rooms.test.js (нужен установленный ws)
const { spawn } = require('child_process');
const os = require('os'), path = require('path'), fs = require('fs');
const assert = require('assert');
const PORT = 3100 + Math.floor(Math.random() * 500);
const DATA = path.join(os.tmpdir(), 'nysr-test-' + process.pid + '.json');
let proc;
const sleep = ms => new Promise(r => setTimeout(r, ms));
function start() {
  proc = spawn('node', [path.join(__dirname, '..', 'server', 'server.js')], { env: { ...process.env, PORT, DATA_FILE: DATA }, stdio: 'ignore' });
  return sleep(700);
}
async function stop() { proc.kill('SIGTERM'); await sleep(400); }
function client() {
  const ws = new WebSocket('ws://localhost:' + PORT + '/ws'); const log = []; const waiters = [];
  ws.onmessage = e => { const m = JSON.parse(e.data); log.push(m); waiters.splice(0).forEach(w => w()); };
  const c = {
    ws, log,
    send: o => ws.send(JSON.stringify(o)),
    open: () => new Promise(r => { ws.onopen = r; }),
    async wait(pred, ms = 2000, from = 0) {
      const t0 = Date.now();
      for (;;) { const f = log.slice(from).find(pred); if (f) return f; if (Date.now() - t0 > ms) throw new Error('timeout, log=' + JSON.stringify(log.slice(-3))); await new Promise(r => { waiters.push(r); setTimeout(r, 100); }); }
    },
    last: t => [...log].reverse().find(m => m.t === t)
  };
  return c;
}
async function conn() { const c = client(); await c.open(); return c; }
const tests = [];
const test = (n, f) => tests.push([n, f]);

let CODE, A, B, TOKB;
test('создание комнаты: код из 5 символов, организатор', async () => {
  A = await conn(); A.send({ t: 'create', name: 'Аня' });
  const j = await A.wait(m => m.t === 'joined'); CODE = j.code;
  assert(/^[A-HJ-NP-Z2-9]{5}$/.test(CODE), 'код ' + CODE);
  const r = (await A.wait(m => m.t === 'room')).room;
  assert.equal(r.hostId, j.you); assert.equal(r.players.length, 1); assert.equal(r.max, 30);
});
test('вход по коду, имена в реальном времени, токены не утекают', async () => {
  B = await conn(); B.send({ t: 'peek', code: CODE.toLowerCase() });
  assert((await B.wait(m => m.t === 'peek')).exists);
  B.send({ t: 'join', code: CODE, name: 'Борис' });
  const j = await B.wait(m => m.t === 'joined'); TOKB = j.token;
  await A.wait(m => m.t === 'room' && m.room.players.length === 2);
  assert(!JSON.stringify(A.log).includes(TOKB), 'токен Бориса виден организатору!');
});
test('дубликат имени и неверное имя отклоняются', async () => {
  const C = await conn(); C.send({ t: 'join', code: CODE, name: ' аня ' });
  assert.equal((await C.wait(m => m.t === 'error')).code, 'name_taken');
  C.send({ t: 'join', code: CODE, name: '   ' });
  await C.wait(m => m.code === 'bad_name'); C.ws.close();
});
test('несуществующая комната', async () => {
  const C = await conn(); C.send({ t: 'join', code: 'ZZZZZ', name: 'X' });
  assert.equal((await C.wait(m => m.t === 'error')).code, 'not_found'); C.ws.close();
});
test('отключение: статус офлайн, возврат по токену на то же место', async () => {
  const a0 = A.log.length; B.ws.close();
  await A.wait(m => m.t === 'room' && m.room.players[1] && m.room.players[1].online === false, 2000, a0);
  const B2 = await conn(); B2.send({ t: 'join', code: CODE, token: TOKB });
  assert.equal((await B2.wait(m => m.t === 'joined')).token, TOKB);
  const r = (await A.wait(m => m.t === 'room' && m.room.players[1] && m.room.players[1].online === true, 2000, a0)).room;
  assert.equal(r.players.length, 2); assert.equal(r.players[1].name, 'Борис'); B = B2;
});
test('неверный токен без имени -> bad_token', async () => {
  const C = await conn(); C.send({ t: 'join', code: CODE, token: 'deadbeef' });
  assert.equal((await C.wait(m => m.t === 'error')).code, 'bad_token'); C.ws.close();
});
test('только организатор закрывает набор; закрытая комната не принимает', async () => {
  B.send({ t: 'setclosed', closed: true });
  assert.equal((await B.wait(m => m.t === 'error')).code, 'not_host');
  A.send({ t: 'setclosed', closed: true });
  await B.wait(m => m.t === 'room' && m.room.closed === true);
  const C = await conn(); C.send({ t: 'join', code: CODE, name: 'Вика' });
  assert.equal((await C.wait(m => m.t === 'error')).code, 'closed');
  C.send({ t: 'peek', code: CODE }); assert((await C.wait(m => m.t === 'peek')).closed); C.ws.close();
  assert(!JSON.stringify(B.log).includes('"token"') || B.log.filter(m => m.t === 'room').every(m => !JSON.stringify(m).includes('token')));
});
test('сохранение данных: перезапуск сервера', async () => {
  const tokA = A.last('joined').token;
  await stop(); await start();
  A = await conn(); A.send({ t: 'join', code: CODE, token: tokA }); await A.wait(m => m.t === 'joined'); // организатор тоже возвращается
  const B3 = await conn(); B3.send({ t: 'join', code: CODE, token: TOKB });
  await B3.wait(m => m.t === 'joined');
  const r = (await B3.wait(m => m.t === 'room')).room;
  assert.equal(r.players.length, 2); assert.equal(r.closed, true); B = B3;
});
test('лимит 30 участников', async () => {
  const H = await conn(); H.send({ t: 'create', name: 'Хост' }); const code = (await H.wait(m => m.t === 'joined')).code;
  const extra = [];
  for (let i = 1; i < 30; i++) { const c = await conn(); c.send({ t: 'join', code, name: 'P' + i }); await c.wait(m => m.t === 'joined'); extra.push(c); }
  const r = (await H.wait(m => m.t === 'room' && m.room.players.length === 30)).room; assert.equal(r.players.length, 30);
  const o = await conn(); o.send({ t: 'peek', code }); assert((await o.wait(m => m.t === 'peek')).full);
  o.send({ t: 'join', code, name: 'Лишний' }); assert.equal((await o.wait(m => m.t === 'error')).code, 'full');
  [H, o, ...extra].forEach(c => c.ws.close());
});
test('выход: организатор передаёт права, пустая комната удаляется', async () => {
  const b0 = B.log.length; A.send({ t: 'leave' }); await A.wait(m => m.t === 'left');
  const r = (await B.wait(m => m.t === 'room' && m.room.players.length === 1, 2000, b0)).room;
  assert.equal(r.hostId, B.last('joined').you); assert.equal(r.closed, true);
  B.send({ t: 'leave' }); await B.wait(m => m.t === 'left');
  const C = await conn(); C.send({ t: 'peek', code: CODE }); assert.equal((await C.wait(m => m.t === 'peek')).exists, false); C.ws.close();
});

(async () => {
  await start(); let fail = 0;
  for (const [n, f] of tests) { try { await f(); console.log('✓', n); } catch (e) { fail++; console.log('✗', n, '\n   ', e.message); } }
  await stop(); try { fs.unlinkSync(DATA); } catch (e) {}
  console.log(fail ? fail + ' тест(ов) упало' : 'Все ' + tests.length + ' тестов прошли'); process.exit(fail ? 1 : 0);
})();
