'use strict';
// Этап 2 в реальном браузере (Playwright, мобильный viewport): отсчёт, рулетка, результат, обновление страницы, скриншоты.
const assert = require('assert'), fs = require('fs'), path = require('path');
const { server, sleep, runAll } = require('./helpers');
let pw; try { pw = require('playwright'); } catch (e) { try { pw = require('/opt/npm-tools/node_modules/playwright'); } catch (e2) { console.log('SKIP: Playwright не установлен'); process.exit(0); } }
const SHOTS = process.env.SHOTS_DIR || '';
const srv = server({ HEARTBEAT_MS: 1000 }); // боевые тайминги: отсчёт 5 с, вращение 9 с
const tests = []; const test = (n, f) => tests.push([n, f]);
const tap = (p, sel) => p.click(sel, { force: true });
let browser, pages = [], ctxs = [], code, frames = [[], [], []];
const shot = async (p, name) => { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await p.screenshot({ path: path.join(SHOTS, name + '.png') }); } };
const mkCtx = () => browser.newContext({ viewport: { width: 390, height: 780 }, isMobile: true, hasTouch: true });

test('3 браузера входят в комнату; кнопка старта у организатора', async () => {
  browser = await pw.chromium.launch();
  for (let i = 0; i < 3; i++) { const c = await mkCtx(); const p = await c.newPage(); p.on('pageerror', e => { throw e; }); p.on('websocket', w => w.on('framereceived', f => frames[i].push(String(f.payload)))); ctxs.push(c); pages.push(p); }
  const [A, B, C] = pages;
  await A.goto(srv.url + '/'); await tap(A, '#btnCreate'); await A.fill('#nameIn', 'Аня'); await tap(A, '#btnName'); await A.waitForSelector('#s-lobby.active');
  code = (await A.textContent('#rCode')).trim();
  for (const [p, n] of [[B, 'Борис'], [C, 'Вика']]) { await p.goto(srv.url + '/?room=' + code); await p.fill('#nameIn', n); await tap(p, '#btnName'); await p.waitForSelector('#s-lobby.active'); }
  await A.waitForFunction(() => document.querySelectorAll('#rList .prow').length === 3 && !document.querySelector('#rList .dot.off'));
  assert(await A.isVisible('#btnStart')); assert(await A.isEnabled('#btnStart')); assert(await B.isHidden('#btnStart'));
  await shot(A, '1-lobby-host');
});
test('офлайн-участник блокирует кнопку и называется по имени', async () => {
  const [A, B] = pages; await ctxs[1].setOffline(true); await B.evaluate(() => ws.close()).catch(() => {});
  await A.waitForFunction(() => document.querySelector('#rList .dot.off'), null, { timeout: 15000 });
  assert(await A.isDisabled('#btnStart')); assert((await A.textContent('#rWait')).includes('Борис'));
  await ctxs[1].setOffline(false); await A.waitForFunction(() => !document.querySelector('#rList .dot.off'), null, { timeout: 20000 }); assert(await A.isEnabled('#btnStart'));
});
test('старт: у всех одновременно отсчёт 5…1, НАЧАЛИ!, одинаковое окончание, результат только свой', async () => {
  const [A, B, C] = pages; await tap(A, '#btnStart'); await tap(A, '#modal .btn.gold');
  const digits = [[], [], []], t = { spin: [], result: [] };
  await Promise.all(pages.map((p, i) => p.exposeFunction('rec' + i, (k, v) => { if (k === 'd') digits[i].push(v); else t[k][i] = Date.now(); }).then(() =>
    p.evaluate(i => { const w = document.getElementById('wWho'); new MutationObserver(() => { const x = w.textContent; (window['rec' + i])('d', x); if (x === 'НАЧАЛИ!') window['rec' + i]('spin'); }).observe(w, { childList: true, characterData: true, subtree: true });
      new MutationObserver(() => { if (document.getElementById('s-result').classList.contains('active')) window['rec' + i]('result'); }).observe(document.getElementById('s-result'), { attributes: true }); }, i))));
  await A.waitForSelector('#s-wheel.active'); await B.waitForSelector('#s-wheel.active'); await C.waitForSelector('#s-wheel.active');
  await sleep(2500); await shot(A, '2-countdown'); await shot(B, '2-countdown-B');
  await A.waitForFunction(() => document.getElementById('wWho').textContent === 'Крутится…', null, { timeout: 12000 }); await sleep(2000); await shot(A, '3-spinning');
  for (const p of pages) await p.waitForSelector('#s-result.active', { timeout: 20000 });
  await sleep(700); await shot(A, '4-result-A'); await shot(B, '4-result-B'); await shot(C, '4-result-C');
  digits.forEach((d, i) => { const seq = d.filter(x => /^[1-5]$|НАЧАЛИ!/.test(x)); assert.deepEqual([...new Set(seq)], ['5', '4', '3', '2', '1', 'НАЧАЛИ!'], 'клиент ' + i + ': ' + seq); });
  const sk = a => Math.max(...a) - Math.min(...a); console.log('   разброс НАЧАЛИ! между браузерами: ' + sk(t.spin) + ' мс; разброс показа результата: ' + sk(t.result) + ' мс');
  assert(sk(t.spin) < 250, 'старт рассинхронизирован'); assert(sk(t.result) < 250, 'финиш рассинхронизирован');
  const got = await Promise.all(pages.map(p => p.textContent('#rTarget'))); const names = ['Аня', 'Борис', 'Вика'];
  got.forEach((g, i) => { assert(names.includes(g) && g !== names[i], 'результат ' + i + ': ' + g); }); assert.equal(new Set(got).size, 3, 'повторы: ' + got);
  assert((await A.textContent('#s-result .lead')).includes('Тебе нужно подарить подарок'));
  frames.forEach((f, i) => names.forEach((n, j) => { if (j !== i) { const own = f.filter(x => x.includes('"t":"result"')); assert.equal(own.length, 1); assert(!own[0].includes(n) || got[i] === n); } }));
});
test('стрелка рулетки действительно остановилась на имени из результата', async () => {
  for (let i = 0; i < 3; i++) {
    const r = await pages[i].evaluate(() => { const m = /rotate\(([-0-9.e]+)rad\)/.exec(document.getElementById('wSpin').style.transform), a = +m[1], n = room.players.length, seg = 2 * Math.PI / n;
      const k = Math.floor((((-a) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI) / seg); return { under: room.players[k].name, target: myResult.target }; });
    assert.equal(r.under, r.target, 'клиент ' + i);
  }
});
test('обновление страницы возвращает тот же результат, без анимации-повтора с новым итогом', async () => {
  const before = await Promise.all(pages.map(p => p.textContent('#rTarget')));
  for (const p of pages) await p.reload();
  for (const p of pages) await p.waitForSelector('#s-result.active', { timeout: 10000 });
  assert.deepEqual(await Promise.all(pages.map(p => p.textContent('#rTarget'))), before);
  await shot(pages[0], '5-result-after-reload');
});
test('перезапуск сервера: браузеры переподключаются и видят тот же результат', async () => {
  const before = await Promise.all(pages.map(p => p.textContent('#rTarget')));
  await srv.kill9(); await srv.start(); await sleep(6000);
  for (const p of pages) await p.reload();
  for (const p of pages) await p.waitForSelector('#s-result.active', { timeout: 15000 });
  assert.deepEqual(await Promise.all(pages.map(p => p.textContent('#rTarget'))), before);
});
test('«На главную» после розыгрыша не теряет результат: вход по коду возвращает на карточку', async () => {
  const before = await pages[2].textContent('#rTarget'); await tap(pages[2], '#btnHome'); await pages[2].waitForSelector('#s-home.active');
  await pages[2].fill('#codeIn', code); await tap(pages[2], '#btnJoin'); await pages[2].waitForSelector('#s-result.active', { timeout: 8000 });
  assert.equal(await pages[2].textContent('#rTarget'), before);
});
test('десктопный вид', async () => {
  const c = await browser.newContext({ viewport: { width: 1280, height: 800 } }), p = await c.newPage(); await p.goto(srv.url + '/?room=' + code);
  await p.waitForSelector('#s-name.active', { timeout: 5000 }).catch(() => {}); await sleep(300); await shot(p, '6-desktop-late-joiner'); await c.close();
});

(async () => { await srv.start(); process.on('exit', () => { try { browser && browser.close(); } catch (e) {} }); await runAll(tests, [srv]); })();
