'use strict';
// Жизненный цикл соединений: замена сокета, обрыв, «мёртвое» соединение, утечки в conns, токены.
const assert = require('assert');
const { server, conn, sleep, runAll } = require('./helpers');
const srv = server({ HEARTBEAT_MS: 250, ROOM_TTL_MS: 1500, CLEANUP_MS: 200 });
const tests = []; const test = (n, f) => tests.push([n, f]);
const until = async (fn, ms = 4000) => { const t0 = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t0 > ms) throw new Error('условие не выполнилось за ' + ms + ' мс'); await sleep(50); } };
async function mkRoom(names) { // первый создаёт, остальные входят; возвращает [{c,name,token,id}], code
  const out = []; let code;
  for (const name of names) {
    const c = await conn(srv);
    c.send(code ? { t: 'join', code, name } : { t: 'create', name });
    const j = await c.wait(m => m.t === 'joined'); code = j.code; out.push({ c, name, token: j.token, id: j.you });
  }
  return { ps: out, code };
}
const online = (c, name, from = 0) => { const r = [...c.log.slice(from)].reverse().find(m => m.t === 'room'); const p = r && r.room.players.find(p => p.name === name); return p && p.online; };

test('замена соединения (другая вкладка): старый сокет закрыт кодом 4001 и убран из conns', async () => {
  const { ps, code } = await mkRoom(['Аня', 'Борис']); const [A, B] = ps;
  assert.equal((await srv.stats()).conns[code], 2);
  const a0 = A.c.log.length;
  const B2 = await conn(srv); B2.send({ t: 'join', code, token: B.token });
  await B2.wait(m => m.t === 'joined');
  assert.equal(await B.c.waitClose(), 4001, 'старый сокет должен получить 4001');
  await sleep(150);
  const st = await srv.stats();
  assert.equal(st.conns[code], 2, 'в Set должны остаться только A и B2, а не ' + st.conns[code]);
  assert(!A.c.log.slice(a0).some(m => m.t === 'room' && m.room.players.some(p => p.name === 'Борис' && !p.online)), 'не должно быть ложного «не в сети» при замене');
  B2.ws.close(); A.c.ws.close();
});

test('после закрытия замещённого сокета онлайн-статус определяется верно', async () => {
  const { ps, code } = await mkRoom(['Вика', 'Гриша']); const [A, B] = ps;
  const B2 = await conn(srv); B2.send({ t: 'join', code, token: B.token }); await B2.wait(m => m.t === 'joined');
  await B.c.waitClose();
  const a0 = A.c.log.length; B2.ws.close();
  await until(() => online(A.c, 'Гриша', a0) === false);       // новый сокет закрылся → офлайн
  const B3 = await conn(srv); B3.send({ t: 'join', code, token: B.token }); await B3.wait(m => m.t === 'joined');
  await until(() => online(A.c, 'Гриша', a0) === true);
  B3.ws.close(); A.c.ws.close();
});

test('внезапный обрыв TCP (без close-кадра): участник «не в сети», Set очищается', async () => {
  const { ps, code } = await mkRoom(['Даша', 'Егор']); const [A, B] = ps;
  const a0 = A.c.log.length; B.c.ws._socket.destroy();
  await until(() => online(A.c, 'Егор', a0) === false);
  await until(async () => ((await srv.stats()).conns[code] || 0) === 1);
  const B2 = await conn(srv); B2.send({ t: 'join', code, token: B.token });
  assert.equal((await B2.wait(m => m.t === 'joined')).you, B.id, 'вернулся на то же место');
  B2.ws.close(); A.c.ws.close();
});

test('«мёртвое» соединение (клиент молчит, pong не отвечает): сервер завершает его по heartbeat', async () => {
  const A = await conn(srv); A.send = A.send; A.send({ t: 'create', name: 'Жанна' });
  const code = (await A.wait(m => m.t === 'joined')).code;
  const dead = await conn(srv, { autoPong: false }); dead.send({ t: 'join', code, name: 'Захар' });
  await dead.wait(m => m.t === 'joined');
  const a0 = A.log.length; const t0 = Date.now();
  await until(() => online(A, 'Захар', a0) === false, 3000);
  const dt = Date.now() - t0;
  assert(dt < 2500, 'обнаружение заняло ' + dt + ' мс');
  assert.notEqual(await dead.waitClose(1000), null, 'сервер должен закрыть мёртвый сокет');
  assert.equal(online(A, 'Жанна'), true, 'живой клиент (отвечает на ping) не должен отключаться');
  await until(async () => ((await srv.stats()).conns[code] || 0) === 1);
  A.ws.close();
});

test('живое соединение переживает много heartbeat-циклов', async () => {
  const { ps } = await mkRoom(['Ира', 'Костя']); await sleep(1200);
  assert.equal(ps[0].c.closed, null); assert.equal(ps[1].c.closed, null);
  assert.equal(online(ps[0].c, 'Костя'), true); ps.forEach(p => p.c.ws.close());
});

test('сокет, перешедший в другую комнату, покидает прежнюю', async () => {
  const { ps, code } = await mkRoom(['Лена', 'Миша']); const [A, B] = ps;
  const a0 = A.c.log.length; B.c.send({ t: 'create', name: 'Миша2' }); await B.c.wait(m => m.t === 'joined' && m.code !== code);
  await until(() => online(A.c, 'Миша', a0) === false);
  assert.equal((await srv.stats()).conns[code], 1); ps.forEach(p => p.c.ws.close());
});

test('очистка: заброшенная комната (после замены сокета) удаляется по TTL, мусора в conns нет', async () => {
  const before = (await srv.stats()).rooms;
  const { ps, code } = await mkRoom(['Нина', 'Олег']);
  const O2 = await conn(srv); O2.send({ t: 'join', code, token: ps[1].token }); await O2.wait(m => m.t === 'joined'); // замена
  await ps[1].c.waitClose();
  [ps[0].c, O2].forEach(c => c.ws.close());
  await until(async () => { const s = await srv.stats(); return s.conns[code] === undefined; });
  await until(async () => (await srv.stats()).rooms <= before, 6000);   // TTL 1.5 с + очистка
  const st = await srv.stats(); assert.equal(st.conns[code], undefined);
});

test('токены не утекают: каждый клиент видит только свой токен', async () => {
  const { ps, code } = await mkRoom(['Паша', 'Рита', 'Саша']);
  ps[0].c.send({ t: 'setclosed', closed: true }); await ps[2].c.wait(m => m.t === 'room' && m.room.closed);
  await sleep(300);
  for (const me of ps) {
    const dump = JSON.stringify(me.c.log);
    assert(dump.includes(me.token), me.name + ' не получил свой токен');
    for (const other of ps) if (other !== me) assert(!dump.includes(other.token), me.name + ' видит токен ' + other.name);
    assert(me.c.log.filter(m => m.t === 'room').every(m => !JSON.stringify(m).includes('token')), 'в room-сообщениях не должно быть токенов');
  }
  const spy = await conn(srv); spy.send({ t: 'peek', code }); spy.send({ t: 'join', code, name: 'Шпион' }); await spy.wait(m => m.t === 'error');
  assert(!JSON.stringify(spy.log).match(/[0-9a-f]{32}/), 'посторонний получил что-то похожее на токен');
  ps.forEach(p => p.c.ws.close()); spy.ws.close();
});

(async () => { await srv.start(); await runAll(tests, [srv]); })();
