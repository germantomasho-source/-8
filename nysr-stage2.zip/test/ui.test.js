'use strict';
// Сквозной тест в реальном браузере (Playwright, мобильный viewport). Если Playwright нет — пропускается.
const assert = require('assert');
const { server, sleep, runAll } = require('./helpers');
let pw; try { pw = require('playwright'); } catch (e) { try { pw = require('/opt/npm-tools/node_modules/playwright'); } catch (e2) { console.log('SKIP: Playwright не установлен'); process.exit(0); } }
const srv = server({ HEARTBEAT_MS: 1000 });
const tests = []; const test = (n, f) => tests.push([n, f]);
const until = async (fn, ms = 8000) => { const t0 = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t0 > ms) throw new Error('таймаут условия'); await sleep(100); } };
let browser, ctxA, ctxB, A, B, code; const frames = { A: [], B: [] };
const tap = (p, sel) => p.click(sel, { force: true });   // кнопки пульсируют, Playwright считает их «нестабильными»
const names = p => p.$$eval('#rList .pn', e => e.map(x => x.textContent));
const watch = (p, key) => p.on('websocket', w => w.on('framereceived', f => frames[key].push(String(f.payload))));
const mkCtx = () => browser.newContext({ viewport: { width: 390, height: 780 }, isMobile: true, hasTouch: true });

test('создание комнаты и вход по ссылке', async () => {
  browser = await pw.chromium.launch(); ctxA = await mkCtx(); ctxB = await mkCtx();
  A = await ctxA.newPage(); B = await ctxB.newPage(); A.on('pageerror', e => { throw e; }); B.on('pageerror', e => { throw e; });
  watch(A, 'A'); watch(B, 'B');
  await A.goto(srv.url + '/'); await tap(A, '#btnCreate'); await A.fill('#nameIn', 'Аня'); await tap(A, '#btnName');
  await A.waitForSelector('#s-lobby.active'); code = (await A.textContent('#rCode')).trim();
  assert(/^[A-HJ-NP-Z2-9]{5}$/.test(code)); assert.equal(await A.textContent('#rLink'), srv.url + '/?room=' + code);
  await B.goto(srv.url + '/?room=' + code); await B.waitForSelector('#s-name.active');
  assert((await B.textContent('#nameTitle')).includes(code));
  await B.fill('#nameIn', 'Борис'); await tap(B, '#btnName'); await B.waitForSelector('#s-lobby.active');
  await until(async () => (await names(A)).length === 2);
  assert.deepEqual(await names(B), ['Аня', 'Борис']); assert((await B.textContent('#rCount')).includes('2 из 30'));
  assert(await B.isHidden('#btnClose'), 'у гостя нет кнопки закрытия'); assert(await A.isVisible('#btnClose'));
});
test('повторное подключение после обновления страницы', async () => {
  await B.reload(); await B.waitForSelector('#s-lobby.active');
  assert.deepEqual(await names(B), ['Аня', 'Борис']); assert((await B.textContent('#rCount')).includes('2 из 30'));
  assert.equal((await B.$$('#rList .dot.off')).length, 0);
});
test('повторное подключение после перезапуска сервера (без обновления страницы)', async () => {
  await srv.kill9(); await A.waitForSelector('#conn:not([hidden])');   // появился индикатор «нет связи»
  await srv.start();
  await until(async () => (await A.isHidden('#conn')) && (await B.isHidden('#conn')), 15000);
  await until(async () => (await A.$$('#rList .dot.off')).length === 0 && (await names(A)).length === 2);
  assert.deepEqual(await names(A), ['Аня', 'Борис']);
});
test('вторая вкладка той же комнаты вытесняет первую; конфликтов и «мусора» нет', async () => {
  const B2 = await ctxB.newPage(); await B2.goto(srv.url + '/?room=' + code); await B2.waitForSelector('#s-lobby.active');
  await B.waitForSelector('#s-home.active'); assert((await B.textContent('#toast')).includes('другой вкладке'));
  assert.deepEqual(await names(B2), ['Аня', 'Борис']);
  await sleep(1500); assert.equal((await B2.$$('#rList .dot.off')).length, 0, 'Борис должен оставаться «в сети»');
  const st = await srv.stats(); assert.equal(st.conns[code], 2, 'A + B2, а не ' + st.conns[code]);
  await B.close(); B = B2;
});
test('закрытие набора: третий не входит; организатор переносит права при выходе', async () => {
  await tap(A, '#btnClose'); await B.waitForSelector('#rClosed:not([hidden])');
  const ctxC = await mkCtx(), C = await ctxC.newPage(); await C.goto(srv.url + '/'); await C.fill('#codeIn', code.toLowerCase()); await tap(C, '#btnJoin');
  await C.waitForSelector('#toast.show'); assert((await C.textContent('#toast')).includes('закрыл')); assert(await C.isVisible('#s-home.active'));
  await tap(A, '#btnLeave'); await tap(A, '#mActs .btn >> text=Выйти'); await A.waitForSelector('#s-home.active');
  await B.waitForFunction(() => document.querySelectorAll('#rList .prow').length === 1);
  assert(await B.isVisible('#btnClose'), 'Борис стал организатором'); assert((await B.textContent('#rList')).includes('организатор'));
  await ctxC.close();
});
test('токены не утекают в кадры WebSocket, которые получает другой участник', async () => {
  const tok = async p => Object.values(await p.evaluate(() => JSON.parse(localStorage.getItem('nysr-sessions-v2'))))[0];
  const tB = await tok(B); assert(tB && tB.length === 32);
  assert(!frames.A.join('').includes(tB), 'Аня увидела токен Бориса');
  assert(frames.B.join('').includes(tB), 'у Бориса есть собственный токен');
});

(async () => { await srv.start(); const r = runAll(tests, [srv]); process.on('exit', () => { try { browser && browser.close(); } catch (e) {} }); await r; })();
