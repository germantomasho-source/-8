'use strict';
// Этап 2: распределение, синхронизация, защита результатов, устойчивость. node test/draw.test.js
const assert = require('assert');
const { server, conn, sleep, runAll } = require('./helpers');
const fast = { COUNTDOWN_LEAD_MS: 300, COUNTDOWN_MS: 1000, SPIN_MS: 1500, CREATE_LIMIT: 1000, HEARTBEAT_MS: 1000 };
const srv = server(fast), srvList = [srv];
const tests = []; const test = (n, f) => tests.push([n, f]);

// комната из n участников: [организатор, ...гости], у каждого name/token/id/code
async function mkRoom(s, n) {
  const host = await conn(s); host.send({ t: 'create', name: 'P1' });
  const j = await host.wait(m => m.t === 'joined'); host.name = 'P1'; host.token = j.token; host.id = j.you; host.code = j.code;
  const all = [host];
  for (let i = 2; i <= n; i++) {
    const c = await conn(s); c.send({ t: 'join', code: host.code, name: 'P' + i });
    const jj = await c.wait(m => m.t === 'joined'); c.name = 'P' + i; c.token = jj.token; c.id = jj.you; c.code = host.code; all.push(c);
  }
  await host.wait(m => m.t === 'room' && m.room.players.length === n && m.room.players.every(p => p.online));
  return all;
}
const results = async (all, ms = 3000) => Promise.all(all.map(c => c.wait(m => m.t === 'result', ms)));
function checkPermutation(all, res) {
  const ids = all.map(c => c.id), targets = res.map(r => r.targetId);
  all.forEach((c, i) => assert.notEqual(targets[i], c.id, c.name + ' получил сам себя'));
  assert.equal(new Set(targets).size, all.length, 'получатели повторяются');
  assert.deepEqual([...targets].sort(), [...ids].sort(), 'не все участники назначены ровно один раз');
  res.forEach((r, i) => assert.equal(r.target, all.find(c => c.id === r.targetId).name));
}
const close = all => all.forEach(c => { try { c.ws.close(); } catch (e) {} });

for (const n of [2, 3, 10, 30]) {
  test('розыгрыш на ' + n + ' участников: никто не получает себя, получатели уникальны, организатор участвует', async () => {
    const all = await mkRoom(srv, n); all[0].send({ t: 'startdraw' });
    const res = await results(all); checkPermutation(all, res);
    assert(res.some(r => r.targetId === all[0].id), 'организатор должен быть чьим-то получателем'); close(all);
  });
}
test('безопасность (30 участников): каждый клиент получает только свой результат, никаких чужих связей в сообщениях', async () => {
  const all = await mkRoom(srv, 30); all[0].send({ t: 'startdraw' }); const res = await results(all); await sleep(300);
  all.forEach((c, i) => {
    const mine = c.log.filter(m => m.t === 'result'); assert.equal(mine.length, 1, c.name + ': ровно одно сообщение result');
    const raw = JSON.stringify(c.log);
    assert(!/"assign"|"perm"/.test(raw), 'в потоке есть служебные поля распределения');
    c.log.filter(m => m.t !== 'result').forEach(m => { const s = JSON.stringify(m); assert(!/"target/.test(s), 'поле target вне result: ' + s.slice(0, 80)); });
    c.log.filter(m => m.room && m.room.draw).forEach(m => assert.deepEqual(Object.keys(m.room.draw).sort(), ['countdownAt', 'spinEnd', 'spinStart']));
    all.forEach(o => { if (o !== c) assert(!raw.includes(o.token), c.name + ' увидел токен ' + o.name); });
  });
  checkPermutation(all, res); close(all);
});
test('синхронизация: у всех одни и те же серверные метки времени, одинаковая длительность, команда доходит почти одновременно', async () => {
  const all = await mkRoom(srv, 10); all[0].send({ t: 'startdraw' }); await results(all); await sleep(200);
  const d = all.map(c => c.log.filter(m => m.room && m.room.draw).pop().room.draw);
  d.forEach(x => assert.deepEqual(x, d[0])); assert.equal(d[0].spinEnd - d[0].spinStart, 1500); assert.equal(d[0].spinStart - d[0].countdownAt, 1000);
  const arr = all.map(c => { const i = c.log.findIndex(m => m.room && m.room.draw); return c.ts[i]; });
  const skew = Math.max(...arr) - Math.min(...arr); console.log('   разброс прихода команды старта между 10 клиентами: ' + skew + ' мс'); assert(skew < 100, 'разброс ' + skew);
  const sync = await all[1].wait(m => m.t === 'room'); assert(typeof sync.now === 'number');
  const t0 = Date.now(); all[1].send({ t: 'sync', c: t0 }); const sy = await all[1].wait(m => m.t === 'sync' && m.c === t0);
  assert(Math.abs(sy.s - Date.now()) < 500, 'серверное время (sync) — тот же компьютер, расхождение мало'); close(all);
});
test('до старта: офлайн-участник блокирует запуск, организатору называют, кто именно; после возвращения — запуск работает', async () => {
  const all = await mkRoom(srv, 3); all[2].ws.terminate();
  await all[0].wait(m => m.t === 'room' && m.room.players.some(p => p.name === 'P3' && !p.online));
  all[0].send({ t: 'startdraw' }); const e = await all[0].wait(m => m.t === 'error' && m.code === 'offline');
  assert.deepEqual(e.names, ['P3']); await sleep(200); assert(!all[0].log.some(m => m.t === 'result'), 'розыгрыш не должен был стартовать');
  const back = await conn(srv); back.send({ t: 'join', code: all[0].code, token: all[2].token }); await back.wait(m => m.t === 'joined');
  back.id = all[2].id; back.name = 'P3'; back.token = all[2].token; all[2] = back;
  await all[0].wait(m => m.t === 'room' && m.room.players.every(p => p.online)); all[0].send({ t: 'startdraw' });
  checkPermutation(all, await results(all)); close(all);
});
test('меньше 2 участников и не-организатор не могут запустить', async () => {
  const [h] = await mkRoom(srv, 1); h.send({ t: 'startdraw' }); await h.wait(m => m.t === 'error' && m.code === 'too_few');
  const all = await mkRoom(srv, 2); all[1].send({ t: 'startdraw' }); await all[1].wait(m => m.t === 'error' && m.code === 'not_host');
  await sleep(200); assert(!all[0].log.some(m => m.t === 'result')); close(all); h.ws.close();
});
test('повторный запуск невозможен: результат и время не меняются; после старта нельзя входить новым, закрывать/открывать набор', async () => {
  const all = await mkRoom(srv, 4); all[0].send({ t: 'startdraw' }); const r1 = await results(all);
  const d1 = all[0].log.filter(m => m.room && m.room.draw).pop().room.draw;
  all[0].send({ t: 'startdraw' }); await all[0].wait(m => m.t === 'error' && m.code === 'started');
  all[0].send({ t: 'setclosed', closed: false }); await all[0].wait(m => m.t === 'error' && m.code === 'started', 2000, all[0].log.length - 1 < 0 ? 0 : all[0].log.length);
  const late = await conn(srv); late.send({ t: 'join', code: all[0].code, name: 'Опоздавший' }); await late.wait(m => m.t === 'error' && m.code === 'started');
  late.send({ t: 'peek', code: all[0].code }); const pk = await late.wait(m => m.t === 'peek'); assert(pk.closed);
  await sleep(300); assert.equal(all[0].log.filter(m => m.t === 'result').length, 1, 'второго result быть не должно');
  const last = all[0].log.filter(m => m.room && m.room.draw).pop().room;
  assert.deepEqual(last.draw, d1); assert.equal(last.players.length, 4);
  const again = await conn(srv); again.send({ t: 'join', code: all[0].code, token: all[1].token }); const r2 = await again.wait(m => m.t === 'result');
  assert.equal(r2.targetId, r1[1].targetId); close(all); late.ws.close(); again.ws.close();
});
test('обновление страницы / обрыв и возврат по токену: тот же результат, без нового распределения', async () => {
  const all = await mkRoom(srv, 5); all[0].send({ t: 'startdraw' }); const r = await results(all);
  for (let i = 0; i < 5; i++) {
    all[i].ws.terminate(); const c = await conn(srv); c.send({ t: 'join', code: all[0].code, token: all[i].token });
    const rr = await c.wait(m => m.t === 'result'); assert.equal(rr.targetId, r[i].targetId); assert.equal(rr.jitter, r[i].jitter); c.ws.close();
  } close(all);
});
test('участник вышел после старта: его результат сохраняется, список не меняется, вернуться можно', async () => {
  const all = await mkRoom(srv, 4); all[0].send({ t: 'startdraw' }); const r = await results(all);
  all[2].send({ t: 'leave' }); const l = await all[2].wait(m => m.t === 'left'); assert(l.kept);
  const room = (await all[0].wait(m => m.t === 'room' && m.room.players.some(p => !p.online))).room; assert.equal(room.players.length, 4);
  const c = await conn(srv); c.send({ t: 'join', code: all[0].code, token: all[2].token }); const rr = await c.wait(m => m.t === 'result');
  assert.equal(rr.targetId, r[2].targetId); close(all); c.ws.close();
});
test('перезапуск сервера (мягкий SIGTERM и жёсткий SIGKILL сразу после старта): результаты восстанавливаются из хранилища', async () => {
  const s = server(fast); srvList.push(s); await s.start();
  for (const hard of [false, true]) {
    const all = await mkRoom(s, 6); all[0].send({ t: 'startdraw' }); const r = await results(all); const d = all[0].log.filter(m => m.room && m.room.draw).pop().room.draw;
    if (hard) await s.kill9(); else await s.stop(); await s.start();
    for (let i = 0; i < 6; i++) {
      const c = await conn(s); c.send({ t: 'join', code: all[0].code, token: all[i].token });
      const rr = await c.wait(m => m.t === 'result'); assert.equal(rr.targetId, r[i].targetId, (hard ? 'SIGKILL' : 'SIGTERM') + ': результат изменился');
      if (i === 0) assert.deepEqual((await c.wait(m => m.t === 'room')).room.draw, d); c.ws.close();
    }
    close(all);
  }
});
test('Саттоло: на 3 участниках выпадают оба возможных цикла, самовыпадений нет (150 розыгрышей)', async () => {
  const seen = new Set();
  for (let k = 0; k < 150; k++) {
    const all = await mkRoom(srv, 3); all[0].send({ t: 'startdraw' }); const r = await results(all); checkPermutation(all, r);
    seen.add(r.map(x => x.target).join('>')); close(all);
  }
  assert.equal(seen.size, 2, 'ожидали оба цикла, получили: ' + [...seen]);
});

(async () => { await srv.start(); await runAll(tests, srvList); })();
