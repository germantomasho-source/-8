'use strict';
const { spawn } = require('child_process');
const path = require('path'), os = require('os');
const WebSocket = require('ws');
const sleep = ms => new Promise(r => setTimeout(r, ms));
function server(env = {}, port, dataFile) {
  const P = port || 3600 + Math.floor(Math.random() * 900);
  const DATA = dataFile || path.join(os.tmpdir(), 'nysr-t-' + process.pid + '-' + P + '.json');
  const o = { port: P, data: DATA, url: 'http://localhost:' + P, proc: null };
  o.start = async () => { o.proc = spawn('node', [path.join(__dirname, '..', 'server', 'server.js')], { env: { ...process.env, PORT: P, DATA_FILE: DATA, NYSR_TEST: '1', ...env }, stdio: 'ignore' }); await sleep(700); };
  o.stop = async () => { o.proc.kill('SIGTERM'); await sleep(400); };
  o.kill9 = async () => { o.proc.kill('SIGKILL'); await sleep(300); };
  o.stats = async () => (await fetch(o.url + '/__stats')).json();
  return o;
}
// клиент на библиотеке ws (нужны autoPong:false и доступ к TCP-сокету)
function client(srv, opts = {}) {
  const ws = new WebSocket('ws://localhost:' + srv.port + '/ws', opts), log = [], c = { ws, log, ts: [], closed: null };
  const waiters = [];
  ws.on('message', d => { c.ts.push(Date.now()); log.push(JSON.parse(d.toString())); waiters.splice(0).forEach(w => w()); });
  ws.on('close', code => { c.closed = code; waiters.splice(0).forEach(w => w()); });
  c.open = () => new Promise((res, rej) => { ws.on('open', res); ws.on('error', rej); });
  c.send = o => ws.send(JSON.stringify(o));
  c.wait = async (pred, ms = 3000, from = 0) => {
    const t0 = Date.now();
    for (;;) { const f = log.slice(from).find(pred); if (f) return f; if (Date.now() - t0 > ms) throw new Error('timeout; последние: ' + JSON.stringify(log.slice(-2))); await new Promise(r => { waiters.push(r); setTimeout(r, 50); }); }
  };
  c.waitClose = async (ms = 3000) => { const t0 = Date.now(); while (c.closed === null) { if (Date.now() - t0 > ms) throw new Error('сокет не закрылся'); await sleep(25); } return c.closed; };
  c.last = t => [...log].reverse().find(m => m.t === t);
  return c;
}
async function conn(srv, opts) { const c = client(srv, opts); await c.open(); return c; }
async function runAll(tests, srvList) {
  let fail = 0;
  for (const [n, f] of tests) { try { await f(); console.log('✓', n); } catch (e) { fail++; console.log('✗', n, '\n   ', e.message); } }
  for (const s of srvList) { try { await s.stop(); } catch (e) {} try { require('fs').unlinkSync(s.data); } catch (e) {} }
  console.log(fail ? fail + ' тест(ов) упало' : 'Все ' + tests.length + ' тестов прошли'); process.exit(fail ? 1 : 0);
}
module.exports = { server, client, conn, sleep, runAll };
